package moneyjarstudio.budgetplanner.expensemanager;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import moneyjarstudio.budgetplanner.expensemanager.Ads.AdsManager;
import moneyjarstudio.budgetplanner.expensemanager.DB.AppDatabase;
import moneyjarstudio.budgetplanner.expensemanager.DB.DatabaseDebugger;
import moneyjarstudio.budgetplanner.expensemanager.DB.entities.User;
import moneyjarstudio.budgetplanner.expensemanager.OnBoarding_Screen.Onboarding_Activity;

import com.google.firebase.FirebaseApp;

import java.util.concurrent.Executors;

/**
 * 🚀 Splash Screen
 * Waits for Firebase Ad IDs to load (or 2 seconds timeout)
 * Then navigates to Onboarding or Main screen.
 * Shows a No Internet dialog if offline.
 */
public class Splash_Screen_Activity extends AppCompatActivity {

    private AppDatabase db;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean adsLoaded = false;
    private boolean delayPassed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_splash_screen);

        db = AppDatabase.getDatabase(this);
        DatabaseDebugger.logDatabase(db);

        // ✅ Check internet before proceeding
        if (!isInternetAvailable()) {
            showNoInternetDialog();
            return;
        }

        // ✅ Initialize Firebase
        FirebaseApp.initializeApp(this);

        // ✅ Initialize AdsManager with callback
        AdsManager.initialize(this, this::onAdsInitialized);

        // ✅ Start 2.5-second delay timer
        handler.postDelayed(() -> {
            delayPassed = true;
            maybeProceed();
        }, 2500);
    }

    /**
     * Check if internet is available.
     */
    private boolean isInternetAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            return activeNetwork != null && activeNetwork.isConnected();
        }
        return false;
    }

    /**
     * Show an alert dialog when there’s no internet connection.
     */
    private void showNoInternetDialog() {
        new AlertDialog.Builder(this)
                .setTitle("No Internet Connection")
                .setMessage("Please check your internet connection and try again.")
                .setCancelable(false)
                .setPositiveButton("Retry", (dialog, which) -> {
                    dialog.dismiss();
                    if (isInternetAvailable()) {
                        recreate(); // reload the activity if connected
                    } else {
                        showNoInternetDialog(); // keep showing until online
                    }
                })
                .setNegativeButton("Exit", (dialog, which) -> {
                    dialog.dismiss();
                    finish();
                })
                .show();
    }

    /**
     * Called when AdsManager finishes loading Firebase ad IDs.
     */
    private void onAdsInitialized() {
        adsLoaded = true;
        maybeProceed();
    }

    /**
     * Proceed only when both:
     *  1️⃣ Ads are initialized
     *  2️⃣ Minimum 2 seconds passed
     */
    private void maybeProceed() {
        if (adsLoaded && delayPassed) {
            proceedToNextScreen();
        }
    }

    /**
     * Continue normal onboarding or main screen logic.
     */
    private void proceedToNextScreen() {
        Executors.newSingleThreadExecutor().execute(() -> {
            User user = db.userDao().getFirstUser();
            Intent intent;

            if (user == null || TextUtils.isEmpty(user.name)) {
                intent = new Intent(this, Onboarding_Activity.class);
                intent.putExtra("step", "name");
            } else if (TextUtils.isEmpty(user.currency_code)) {
                intent = new Intent(this, Onboarding_Activity.class);
                intent.putExtra("step", "currency");
            } else {
                intent = new Intent(this, MainActivity.class);
            }

            runOnUiThread(() -> {
                startActivity(intent);
                finish();
            });
        });
    }
}
