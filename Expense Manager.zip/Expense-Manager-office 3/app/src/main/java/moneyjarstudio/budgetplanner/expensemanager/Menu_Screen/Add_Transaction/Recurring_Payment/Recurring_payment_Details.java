package moneyjarstudio.budgetplanner.expensemanager.Menu_Screen.Add_Transaction.Recurring_Payment;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;

import moneyjarstudio.budgetplanner.expensemanager.DB.AppDatabase;
import moneyjarstudio.budgetplanner.expensemanager.DB.entities.RecurringTransaction;
import moneyjarstudio.budgetplanner.expensemanager.DB.entities.RecurringTransactionSchedule;
import moneyjarstudio.budgetplanner.expensemanager.Menu_Screen.Add_Transaction.Recurring_Payment.Adapter.RecurringScheduleAdapter;
import moneyjarstudio.budgetplanner.expensemanager.R;

public class Recurring_payment_Details extends AppCompatActivity {

    private AppDatabase db;
    private TextView tvTitle, tvAmount, tvFrequency, tvNextDue, tvStartDate, tvEndDate, tvStatus, tvNotes;
    private LinearLayout btnPauseResume, btnDelete;
    private RecyclerView rvSchedules;
    private long recurringId;
    private final SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
    private RecurringTransaction transaction;
    private RecurringScheduleAdapter scheduleAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_recurring_payment_details);

        db = AppDatabase.getDatabase(this);
        recurringId = getIntent().getLongExtra("recurring_id", -1);

        // 🔗 Bind views
        tvTitle = findViewById(R.id.tvRecurringTitle);
        tvAmount = findViewById(R.id.tvRecurringAmount);
        tvFrequency = findViewById(R.id.tvRecurringFrequency);
        tvNextDue = findViewById(R.id.tvRecurringNextDue);
        tvStartDate = findViewById(R.id.tvRecurringStart);
        tvEndDate = findViewById(R.id.tvRecurringEnd);
        tvStatus = findViewById(R.id.tvRecurringStatus);
        tvNotes = findViewById(R.id.tvRecurringNotes);
        btnPauseResume = findViewById(R.id.btnPauseResume);
        btnDelete = findViewById(R.id.btnDelete);
        rvSchedules = findViewById(R.id.rvSchedules);

        rvSchedules.setLayoutManager(new LinearLayoutManager(this));
        scheduleAdapter = new RecurringScheduleAdapter();
        rvSchedules.setAdapter(scheduleAdapter);

        findViewById(R.id.ivBack).setOnClickListener(v -> onBackPressed());
        btnPauseResume.setOnClickListener(v -> toggleStatus());
        btnDelete.setOnClickListener(v -> deleteRecurring());

        loadRecurringDetails();
        loadSchedules();
    }

    private void loadRecurringDetails() {
        Executors.newSingleThreadExecutor().execute(() -> {
            transaction = db.recurringTransactionDao().getByIdSync(recurringId);
            if (transaction != null) {
                runOnUiThread(() -> {
                    tvTitle.setText(transaction.title);
                    tvAmount.setText(String.format(Locale.getDefault(), "₹%.2f", transaction.amount));
                    tvFrequency.setText(capitalize(transaction.frequency));
                    tvNextDue.setText(transaction.next_due_date != null ? sdf.format(transaction.next_due_date) : "N/A");
                    tvStartDate.setText(sdf.format(transaction.start_date));
                    tvEndDate.setText(transaction.end_date == null ? "No end date" : sdf.format(transaction.end_date));
                    tvStatus.setText(capitalize(transaction.status));
                    tvNotes.setText(transaction.notes != null ? transaction.notes : "No notes");
                });
            }
        });
    }

    private void loadSchedules() {
        db.recurringScheduleDao().getSchedulesByRecurringId(recurringId).observe(this, list -> {
            if (list != null && !list.isEmpty()) {
                scheduleAdapter.setData(list);
            } else {
                Toast.makeText(this, "No schedule data found.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void toggleStatus() {
        if (transaction == null) return;
        String newStatus = transaction.status.equalsIgnoreCase("active") ? "paused" : "active";
        transaction.status = newStatus;
        transaction.updated_at = new java.util.Date();
        Executors.newSingleThreadExecutor().execute(() -> {
            db.recurringTransactionDao().update(transaction);
            runOnUiThread(() -> {
                tvStatus.setText(capitalize(newStatus));
                Toast.makeText(this, "Status changed to " + newStatus, Toast.LENGTH_SHORT).show();
            });
        });
    }

    private void deleteRecurring() {
        if (transaction == null) return;
        Executors.newSingleThreadExecutor().execute(() -> {
            db.recurringTransactionDao().delete(transaction);
            runOnUiThread(() -> {
                Toast.makeText(this, "Recurring payment deleted", Toast.LENGTH_SHORT).show();
                finish();
            });
        });
    }

    private String capitalize(String str) {
        if (str == null || str.isEmpty()) return "";
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
}
