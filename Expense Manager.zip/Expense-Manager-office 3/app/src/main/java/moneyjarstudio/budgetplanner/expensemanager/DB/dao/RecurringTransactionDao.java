package moneyjarstudio.budgetplanner.expensemanager.DB.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.Date;
import java.util.List;

import moneyjarstudio.budgetplanner.expensemanager.DB.entities.RecurringTransaction;

@Dao
public interface RecurringTransactionDao {

    // 🔹 Insert new recurring transaction
    @Insert
    long insert(RecurringTransaction recurringTransaction);

    // 🔹 Update existing
    @Update
    void update(RecurringTransaction recurringTransaction);

    // 🔹 Delete recurring transaction
    @Delete
    void delete(RecurringTransaction recurringTransaction);

    // 🔹 Get all recurring transactions for a user
    @Query("SELECT * FROM recurring_transactions WHERE user_id = :userId ORDER BY next_due_date ASC")
    LiveData<List<RecurringTransaction>> getAllRecurringByUser(long userId);

    // 🔹 Get all active recurring payments
    @Query("SELECT * FROM recurring_transactions WHERE user_id = :userId AND status = 'active' ORDER BY next_due_date ASC")
    LiveData<List<RecurringTransaction>> getActiveRecurringByUser(long userId);

    // 🔹 Get recurring transactions due today or earlier
    @Query("SELECT * FROM recurring_transactions WHERE user_id = :userId AND next_due_date <= :today AND status = 'active'")
    List<RecurringTransaction> getDueRecurringPayments(long userId, Date today);

    // 🔹 Get recurring transaction by ID (synchronous)
    @Query("SELECT * FROM recurring_transactions WHERE recurring_id = :id LIMIT 1")
    RecurringTransaction getByIdSync(long id);

    // 🔹 Update status (Active / Paused / Completed)
    @Query("UPDATE recurring_transactions SET status = :newStatus, updated_at = :updatedAt WHERE recurring_id = :id")
    void updateStatus(long id, String newStatus, Date updatedAt);

    // 🔹 Update next due date (after a payment is processed)
    @Query("UPDATE recurring_transactions SET next_due_date = :nextDueDate, completed_payments = completed_payments + 1, updated_at = :updatedAt WHERE recurring_id = :id")
    void updateNextDue(long id, Date nextDueDate, Date updatedAt);

    // 🔹 Delete all completed recurring transactions (optional cleanup)
    @Query("DELETE FROM recurring_transactions WHERE status = 'completed'")
    void deleteCompletedRecurring();

    @Query("SELECT * FROM recurring_transactions WHERE user_id = :userId AND status = :status ORDER BY next_due_date ASC")
    LiveData<List<RecurringTransaction>> getRecurringByUserAndStatus(long userId, String status);


}
