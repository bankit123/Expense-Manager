package moneyjarstudio.budgetplanner.expensemanager.DB.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.Date;
import java.util.List;

import moneyjarstudio.budgetplanner.expensemanager.DB.entities.RecurringTransactionSchedule;

@Dao
public interface RecurringScheduleDao {

    // 🟢 Insert a new schedule entry
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(RecurringTransactionSchedule schedule);

    // 🟠 Bulk insert (for creating many schedules at once)
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<RecurringTransactionSchedule> schedules);

    // 🟣 Update a schedule (e.g., mark as done/missed)
    @Update
    void update(RecurringTransactionSchedule schedule);

    // 🔍 Fetch all schedules for one recurring payment
    @Query("SELECT * FROM recurring_transaction_schedule WHERE recurring_id = :recurringId ORDER BY scheduled_date ASC")
    LiveData<List<RecurringTransactionSchedule>> getSchedulesByRecurringId(long recurringId);

    // 📅 Fetch upcoming (future) schedules
    @Query("SELECT * FROM recurring_transaction_schedule WHERE recurring_id = :recurringId AND status = 'upcoming' ORDER BY scheduled_date ASC")
    LiveData<List<RecurringTransactionSchedule>> getUpcomingSchedules(long recurringId);

    // ✅ Fetch completed (done) schedules
    @Query("SELECT * FROM recurring_transaction_schedule WHERE recurring_id = :recurringId AND status = 'done' ORDER BY scheduled_date DESC")
    LiveData<List<RecurringTransactionSchedule>> getCompletedSchedules(long recurringId);

    // ⚠️ Fetch missed schedules (past due but unpaid)
    @Query("SELECT * FROM recurring_transaction_schedule WHERE recurring_id = :recurringId AND status = 'missed' ORDER BY scheduled_date ASC")
    LiveData<List<RecurringTransactionSchedule>> getMissedSchedules(long recurringId);

    // 🧮 Count how many payments are done for a recurring rule
    @Query("SELECT COUNT(*) FROM recurring_transaction_schedule WHERE recurring_id = :recurringId AND status = 'done'")
    int getCompletedCount(long recurringId);

    // 🕒 Find next upcoming schedule for a recurring payment
    @Query("SELECT * FROM recurring_transaction_schedule WHERE recurring_id = :recurringId AND status = 'upcoming' ORDER BY scheduled_date ASC LIMIT 1")
    RecurringTransactionSchedule getNextUpcomingScheduleSync(long recurringId);

    // ⚠️ Find all overdue schedules (missed payments)
    @Query("SELECT * FROM recurring_transaction_schedule WHERE status = 'upcoming' AND scheduled_date < :today")
    List<RecurringTransactionSchedule> getOverdueSchedules(Date today);

    // 🔄 Mark missed schedules automatically when date passes
    @Query("UPDATE recurring_transaction_schedule SET status = 'missed' WHERE status = 'upcoming' AND scheduled_date < :today")
    void markOverdueAsMissed(Date today);

    // 🧩 Find by transaction_id (useful when deleting a transaction)
    @Query("SELECT * FROM recurring_transaction_schedule WHERE transaction_id = :transactionId LIMIT 1")
    RecurringTransactionSchedule getByTransactionIdSync(long transactionId);

    // 🚮 Delete a schedule (usually not needed unless rollback)
    @Query("DELETE FROM recurring_transaction_schedule WHERE schedule_id = :scheduleId")
    void deleteById(long scheduleId);
}

