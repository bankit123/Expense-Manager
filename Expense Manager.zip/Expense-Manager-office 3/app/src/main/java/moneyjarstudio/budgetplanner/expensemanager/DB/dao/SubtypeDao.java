package moneyjarstudio.budgetplanner.expensemanager.DB.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.*;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import moneyjarstudio.budgetplanner.expensemanager.DB.entities.Subtype;

import java.util.List;

@Dao
public interface SubtypeDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Subtype subtype);

    @Update
    void updateSubtype(Subtype subtype);

    @Delete
    void deleteSubtype(Subtype subtype);

    @Query("SELECT * FROM subtypes")
    List<Subtype> getAllSubtypes();  // ✅ For background thread use

    @Query("SELECT * FROM subtypes WHERE account_id = :accountId ORDER BY subtype_id ASC")
    LiveData<List<Subtype>> getSubtypesByAccountIdLive(long accountId);

    @Query("SELECT * FROM subtypes WHERE subtype_id = :id LIMIT 1")
    Subtype getSubtypeById(long id);

    @Query("DELETE FROM subtypes WHERE account_id = :accountId")
    void deleteSubtypesByAccountId(long accountId);

    @Query("SELECT * FROM subtypes WHERE account_id = :accountId ORDER BY subtype_id ASC")
    List<Subtype> getSubtypesByAccountId(long accountId);


    @Query("SELECT * FROM subtypes")
    LiveData<List<Subtype>> getAllSubtypesLive();

}