package moneyjarstudio.budgetplanner.expensemanager.Menu_Screen.Add_Transaction.Recurring_Payment.Adapter;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import moneyjarstudio.budgetplanner.expensemanager.DB.entities.RecurringTransactionSchedule;
import moneyjarstudio.budgetplanner.expensemanager.R;

public class RecurringScheduleAdapter extends RecyclerView.Adapter<RecurringScheduleAdapter.ScheduleViewHolder> {

    private final List<RecurringTransactionSchedule> scheduleList = new ArrayList<>();
    private final SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());

    public void setData(List<RecurringTransactionSchedule> newList) {
        scheduleList.clear();
        scheduleList.addAll(newList);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ScheduleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recurring_schedule, parent, false);
        return new ScheduleViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ScheduleViewHolder holder, int position) {
        RecurringTransactionSchedule item = scheduleList.get(position);

        holder.tvDate.setText(sdf.format(item.scheduled_date));
        holder.tvAmount.setText(String.format(Locale.getDefault(), "₹%.2f", item.amount));

        switch (item.status.toLowerCase(Locale.ROOT)) {
            case "done":
                holder.tvStatus.setText("Completed");
                holder.tvStatus.setTextColor(Color.parseColor("#4CAF50")); // Green
                break;
            case "missed":
                holder.tvStatus.setText("Missed");
                holder.tvStatus.setTextColor(Color.parseColor("#F44336")); // Red
                break;
            default:
                holder.tvStatus.setText("Upcoming");
                holder.tvStatus.setTextColor(Color.parseColor("#FF9800")); // Orange
                break;
        }
    }

    @Override
    public int getItemCount() {
        return scheduleList.size();
    }

    static class ScheduleViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate, tvAmount, tvStatus;

        public ScheduleViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvScheduleDate);
            tvAmount = itemView.findViewById(R.id.tvScheduleAmount);
            tvStatus = itemView.findViewById(R.id.tvScheduleStatus);
        }
    }
}
