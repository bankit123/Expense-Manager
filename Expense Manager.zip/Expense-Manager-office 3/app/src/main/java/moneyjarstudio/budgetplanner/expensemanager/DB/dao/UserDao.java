package moneyjarstudio.budgetplanner.expensemanager.DB.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import moneyjarstudio.budgetplanner.expensemanager.DB.entities.User;

import java.util.List;

@Dao
public interface UserDao {
    @Insert
    long insert(User user);
    @Update
    void update(User user);
    @Delete
    void delete(User user);

    @Query("SELECT * FROM users LIMIT 1")
    User getFirstUser();

    @Query("SELECT * FROM users WHERE user_id = :id")
    User getUserById(long id);

    @Query("SELECT * FROM users")
    List<User> getAllUsers();
}
