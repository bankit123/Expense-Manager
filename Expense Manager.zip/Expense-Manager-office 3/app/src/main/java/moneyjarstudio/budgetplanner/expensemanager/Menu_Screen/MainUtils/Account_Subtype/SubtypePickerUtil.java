package moneyjarstudio.budgetplanner.expensemanager.Menu_Screen.MainUtils.Account_Subtype;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.lifecycle.LifecycleOwner;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;
import java.util.List;

import moneyjarstudio.budgetplanner.expensemanager.DB.AppDatabase;
import moneyjarstudio.budgetplanner.expensemanager.DB.entities.Account;
import moneyjarstudio.budgetplanner.expensemanager.DB.entities.Subtype;
import moneyjarstudio.budgetplanner.expensemanager.Menu_Screen.Account_Screen.Add_Account_Activity;
import moneyjarstudio.budgetplanner.expensemanager.R;

public class SubtypePickerUtil {

    public interface OnSubtypeSelected {
        void onSelected(Subtype subtype);
    }

    public static void showSubtypePicker(Context context,
                                         ImageView ivSubtypeIcon,
                                         TextView tvSubtype,
                                         OnSubtypeSelected callback) {

        BottomSheetDialog dialog = new BottomSheetDialog(context);
        View sheetView = LayoutInflater.from(context).inflate(R.layout.bottom_sheet_subtype, null);
        dialog.setContentView(sheetView);

        ImageView closeBottomSheet = sheetView.findViewById(R.id.closeBottomSheet);
        closeBottomSheet.setOnClickListener(v -> dialog.dismiss());

        LinearLayout btnAddSubtype = sheetView.findViewById(R.id.btnAddSubtype);
        RecyclerView rvSubtypes = sheetView.findViewById(R.id.rvSubtypes);

        // 🔹 Add New Subtype Button — Open Add_Account_Activity (you can replace with Add_Subtype_Activity)
        btnAddSubtype.setOnClickListener(v -> {
            Intent intent = new Intent(context, Add_Account_Activity.class);
            context.startActivity(intent);
            dialog.dismiss();
        });

        // 🔹 Initialize Database
        AppDatabase db = AppDatabase.getDatabase(context);

        // 🔹 Use LiveData — observe all subtypes in real time
        db.accountDao().getAllAccountsLive().observe((LifecycleOwner) context, accounts -> {
            db.subtypeDao().getAllSubtypesLive().observe((LifecycleOwner) context, subtypes -> {
                if (accounts == null || subtypes == null) return;

                List<Object> combinedList = new ArrayList<>();

                // 🧩 Combine Accounts + Subtypes
                for (Account account : accounts) {
                    combinedList.add(account);
                    for (Subtype subtype : subtypes) {
                        if (subtype.account_id == account.account_id) {
                            combinedList.add(subtype);
                        }
                    }
                }

                // ✅ Use GridLayoutManager with 3 columns
                GridLayoutManager layoutManager = new GridLayoutManager(context, 3);

                // ✅ Make Account rows full-width
                layoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                    @Override
                    public int getSpanSize(int position) {
                        Object item = combinedList.get(position);
                        return (item instanceof Account) ? 3 : 1;
                    }
                });

                rvSubtypes.setLayoutManager(layoutManager);

                // ✅ Attach Adapter
                rvSubtypes.setAdapter(new SubtypePickerGroupedAdapter(context, combinedList, subtype -> {
                    // Update UI when subtype selected
                    int resId = context.getResources().getIdentifier(subtype.icon, "drawable", context.getPackageName());
                    ivSubtypeIcon.setImageResource(resId);
                    tvSubtype.setText(subtype.name);

                    callback.onSelected(subtype);
                    dialog.dismiss();
                }));
            });
        });

        dialog.show();
    }
}
