package moneyjarstudio.budgetplanner.expensemanager.Profile;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import moneyjarstudio.budgetplanner.expensemanager.DB.AppDatabase;
import moneyjarstudio.budgetplanner.expensemanager.DB.entities.User;
import moneyjarstudio.budgetplanner.expensemanager.OnBoarding_Screen.Currency_Input_Fragment;
import moneyjarstudio.budgetplanner.expensemanager.Profile.Categories.Categories_For_Profile;
import moneyjarstudio.budgetplanner.expensemanager.Profile.Subtype.Subtype_For_Profile_Activity;
import moneyjarstudio.budgetplanner.expensemanager.R;

import java.util.concurrent.Executors;

public class Profile_Activity extends AppCompatActivity implements Currency_Input_Fragment.OnCurrencySavedListener {

    LinearLayout changeCurrency;
    ImageView ivBack;
    TextView userNameText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);

        // 🔹 Find the views
        changeCurrency = findViewById(R.id.changeCurrency);
        ivBack = findViewById(R.id.ivBack);
        userNameText = findViewById(R.id.userName);

        // 🔹 Back button
        ivBack.setOnClickListener(v -> finish());

        // 🔹 Change currency
        changeCurrency.setOnClickListener(v -> openCurrencyChange());

        LinearLayout AccountLayout = findViewById(R.id.Account);
        AccountLayout.setOnClickListener(v -> {
            Intent intent = new Intent(Profile_Activity.this, Subtype_For_Profile_Activity.class);
            startActivity(intent);
        });

        // 🔹 Categories
        LinearLayout categoriesLayout = findViewById(R.id.categories);
        categoriesLayout.setOnClickListener(v -> {
            Intent intent = new Intent(Profile_Activity.this, Categories_For_Profile.class);
            startActivity(intent);
        });

        // 🔹 About Us
        LinearLayout aboutUsLayout = findViewById(R.id.aboutUs);
        aboutUsLayout.setOnClickListener(v -> {
            Intent intent = new Intent(Profile_Activity.this, AboutUs_Activity.class);
            startActivity(intent);
        });

        LinearLayout privacyPolicyLayout = findViewById(R.id.PrivacyPolicy);
        privacyPolicyLayout.setOnClickListener(v -> {
            Intent intent = new Intent(Profile_Activity.this, Privacy_Policy_Activity.class);
            startActivity(intent);
        });

        LinearLayout share = findViewById(R.id.share);

        share.setOnClickListener(v -> {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "TrackMySpend – Expense Manager");

            String shareMessage = "💰 TrackMySpend – Expense Manager 📊\n\n" +
                    "Take control of your money like a pro!\n" +
                    "Easily manage your daily expenses, track income, and stay on budget — all in one app.\n\n" +
                    "✨ Key Features:\n" +
                    "• 💵 Add & categorize your expenses\n" +
                    "• 📆 View weekly, monthly, or yearly stats\n" +
                    "• 📊 Smart charts & insights\n" +
                    "• 💡 Manage EMIs and bills\n" +
                    "• ☁️ Backup your data securely\n\n" +
                    "Download now and start tracking smarter!\n👇\n" +
                    "https://play.google.com/store/apps/details?id=" + getPackageName();

            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "Share via"));
        });



        // ✅ Load User Name from DB
        Executors.newSingleThreadExecutor().execute(() -> {
            AppDatabase db = AppDatabase.getDatabase(getApplicationContext());
            User user = db.userDao().getFirstUser();

            runOnUiThread(() -> {
                if (user != null && user.name != null && !user.name.isEmpty()) {
                    String name = user.name.trim();
                    String capitalizedName = name.substring(0, 1).toUpperCase() + name.substring(1);
                    userNameText.setText(capitalizedName);
                }
                else {
                    userNameText.setText("Guest User"); // fallback
                }
            });
        });
    }

    private void openCurrencyChange() {
        Currency_Input_Fragment fragment = new Currency_Input_Fragment();

        Bundle args = new Bundle();
        args.putBoolean("fromProfile", true);
        fragment.setArguments(args);

        getSupportFragmentManager()
                .beginTransaction()
                .setCustomAnimations(
                        R.anim.slide_in_right,
                        R.anim.slide_out_left,
                        R.anim.slide_in_left,
                        R.anim.slide_out_right
                )
                .replace(android.R.id.content, fragment)
                .addToBackStack(null)
                .commit();
    }

    // ✅ Called when currency is updated
    @Override
    public void onCurrencySaved() {
        getSupportFragmentManager().popBackStack();
    }
}
