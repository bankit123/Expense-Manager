package moneyjarstudio.budgetplanner.expensemanager.Menu_Screen.Add_Transaction;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import moneyjarstudio.budgetplanner.expensemanager.DB.AppDatabase;
import moneyjarstudio.budgetplanner.expensemanager.DB.entities.Category;
import moneyjarstudio.budgetplanner.expensemanager.DB.entities.Subtype;
import moneyjarstudio.budgetplanner.expensemanager.DB.entities.Transaction;
import moneyjarstudio.budgetplanner.expensemanager.Menu_Screen.Add_Transaction.Recurring_Payment.Recurring_Payment_Activity;
import moneyjarstudio.budgetplanner.expensemanager.Menu_Screen.MainUtils.Account_Subtype.SubtypePickerUtil;
import moneyjarstudio.budgetplanner.expensemanager.Menu_Screen.MainUtils.Category.Adapter.CategoryAdapter;
import moneyjarstudio.budgetplanner.expensemanager.Menu_Screen.MainUtils.Category.CategoryUtil;
import moneyjarstudio.budgetplanner.expensemanager.R;
import moneyjarstudio.budgetplanner.expensemanager.Util.CurrencyFormatterUtil;
import moneyjarstudio.budgetplanner.expensemanager.Util.ReviewUtils;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.Locale;

public class AddTransactionActivity extends AppCompatActivity {

    private TextView tvSpend, tvIncome, tvDateTime, tvCategory, tvPayeeLabel, tvAmountTitle, tvSubtype;
    private TextView currencySymbol;

    private EditText etPayee, etAmount, etNotes;
    private ImageView ivCalendar, ivCategoryIconTransaction, ivSubtypeIcon;
    private LinearLayout layoutCategory, layoutSubtype;
    private LinearLayout btnDelete;

    private boolean isExpense = true;
    private final Calendar calendar = Calendar.getInstance();
    private final SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy, hh:mm a", Locale.getDefault());
    private AppDatabase db;

    // Stored values
    private long transactionId = -1;
    private long selectedCategoryId = -1;
    private long selectedSubtypeId = -1;

    private boolean isCategorySheetOpenedOnce = false;
    private boolean isSubtypeSheetOpenedOnce = false;
    private boolean isCategoryOpenedAfterSwitch = false;


    private ActivityResultLauncher<Intent> addCategoryLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_transaction);

        db = AppDatabase.getDatabase(this);

        // Init UI
        layoutCategory = findViewById(R.id.layoutCategory);
        tvCategory = findViewById(R.id.tvCategory);
        ivCategoryIconTransaction = findViewById(R.id.ivCategoryIconTransaction);

        layoutSubtype = findViewById(R.id.layoutSubtype);
        ivSubtypeIcon = findViewById(R.id.ivSubtypeIcon);
        tvSubtype = findViewById(R.id.tvSubtype);

        currencySymbol = findViewById(R.id.currencySymbol);
        tvAmountTitle = findViewById(R.id.tvAmountTitle);
        tvSpend = findViewById(R.id.tvSpend);
        tvIncome = findViewById(R.id.tvIncome);
        tvPayeeLabel = findViewById(R.id.tvPayeeLabel);
        etPayee = findViewById(R.id.etPayee);
        etAmount = findViewById(R.id.etAmount);
        etNotes = findViewById(R.id.etNotes);
        tvDateTime = findViewById(R.id.tvDateTime);
        ivCalendar = findViewById(R.id.ivCalendar);
//        btnDelete = findViewById(R.id.btnDelete);

        ImageView ivBack = findViewById(R.id.ivBack);
        ImageView ivClose = findViewById(R.id.ivClose);

        currencySymbol.setText(CurrencyFormatterUtil.getCurrencySymbol());

        // ✅ When user presses Done on Amount field → move to Payee (keep keyboard open)
        etAmount.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                etPayee.requestFocus(); // just move focus
                return true;
            }
            return false;
        });


// ✅ When user presses Done on Payee field → close keyboard + open Category (only once)
        etPayee.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {

                // ✅ Close keyboard safely
                v.clearFocus();
                android.view.inputmethod.InputMethodManager imm =
                        (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }

                // ✅ Scroll a bit for smooth bottom sheet display
                v.postDelayed(() -> {
                    View scrollView = findViewById(R.id.scrollView);
                    if (scrollView instanceof android.widget.ScrollView) {
                        ((android.widget.ScrollView) scrollView).smoothScrollTo(0, 0);
                    }
                }, 100);

                // ✅ Open Category only the first time for new transactions
                if (transactionId == -1 && !isCategorySheetOpenedOnce) {
                    isCategorySheetOpenedOnce = true;
                    v.postDelayed(() -> showCategoryBottomSheet(1), 150);
                }

                return true;
            }
            return false;
        });




        // ✅ Register generic launcher
        addCategoryLauncher = CategoryUtil.registerAddCategoryLauncher(this, () -> {
            // Refresh bottom sheet after adding new category
            showCategoryBottomSheet(1);
        });


        ivBack.setOnClickListener(v -> onBackPressed());
        ivClose.setOnClickListener(v -> {
            Intent intent = new Intent(this, Recurring_Payment_Activity.class);
            startActivity(intent);
        });


        // Default → Spend
        setFilterSelected(tvSpend, tvIncome);
        isExpense = true;
        updatePayeeLabel();

        // Clicks
        layoutCategory.setOnClickListener(v -> showCategoryBottomSheet(1));
        layoutSubtype.setOnClickListener(v -> setupSubtypePicker());

        tvSpend.setOnClickListener(v -> {
            clearForm();
            setFilterSelected(tvSpend, tvIncome);
            isExpense = true;
            updatePayeeLabel();

            // Reset automation flags for new flow
            resetFlowFlags();
        });

        tvIncome.setOnClickListener(v -> {
            clearForm();
            setFilterSelected(tvIncome, tvSpend);
            isExpense = false;
            updatePayeeLabel();

            // Reset automation flags for new flow
            resetFlowFlags();
        });



        tvDateTime.setText(sdf.format(calendar.getTime()));
        setupDateTimePicker(tvDateTime, ivCalendar);

        // Save
        findViewById(R.id.btnSave).setOnClickListener(v -> {
            if (transactionId == -1) {
                saveTransaction();
                ReviewUtils.showInAppReview(this);

            } else {
                updateTransaction();
                ReviewUtils.showInAppReview(this);

            }
        });

        // Delete
//        btnDelete.setOnClickListener(v -> deleteTransaction());

        // ✅ Check edit mode
        transactionId = getIntent().getLongExtra("transaction_id", -1);
        if (transactionId != -1) {
            loadTransaction(transactionId);
        }
//        else {
//            btnDelete.setVisibility(View.GONE);
//        }
    }

    private void resetFlowFlags() {
        isCategorySheetOpenedOnce = false;
        isSubtypeSheetOpenedOnce = false;
        isCategoryOpenedAfterSwitch = false;
    }


    private void setFilterSelected(TextView selected, TextView other) {
        int activeColor = getResources().getColor(R.color.nav_icon_active, getTheme());
        int defaultColor = getResources().getColor(R.color.nav_icon_default, getTheme());

        selected.setBackgroundResource(R.drawable.bg_segment_selected);
        selected.setTextColor(activeColor);
        other.setBackgroundResource(R.drawable.bg_segment_unselected);
        other.setTextColor(defaultColor);
    }

    private void setupDateTimePicker(TextView targetView, ImageView triggerIcon) {
        View.OnClickListener openPicker = v -> {
            DatePickerDialog datePicker = new DatePickerDialog(
                    AddTransactionActivity.this,
                    (view, year, month, dayOfMonth) -> {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, month);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                        TimePickerDialog timePicker = new TimePickerDialog(
                                AddTransactionActivity.this,
                                (timeView, hourOfDay, minute) -> {
                                    calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                                    calendar.set(Calendar.MINUTE, minute);
                                    targetView.setText(sdf.format(calendar.getTime()));
                                },
                                calendar.get(Calendar.HOUR_OF_DAY),
                                calendar.get(Calendar.MINUTE),
                                false
                        );
                        timePicker.show();
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );
            datePicker.show();
        };

        targetView.setOnClickListener(openPicker);
        if (triggerIcon != null) triggerIcon.setOnClickListener(openPicker);
    }

    private void setupSubtypePicker() {
        SubtypePickerUtil.showSubtypePicker(this, ivSubtypeIcon, tvSubtype, subtype -> {
            selectedSubtypeId = subtype.subtype_id;
        });
    }

    private void showCategoryBottomSheet(long userId) {
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        View sheetView = getLayoutInflater().inflate(R.layout.bottom_sheet_category, null);
        dialog.setContentView(sheetView);

        ImageView closeBottomSheet = sheetView.findViewById(R.id.closeBottomSheet);
        closeBottomSheet.setOnClickListener(v -> {
            dialog.dismiss();
        });

        LinearLayout btnAddNewCategory = sheetView.findViewById(R.id.btnAddCategory);
        RecyclerView rvCategories = sheetView.findViewById(R.id.rvCategories);
        rvCategories.setLayoutManager(new GridLayoutManager(this, 3));

        db.categoryDao().getCategoriesByUserAndType(userId, isExpense ? "Expense" : "Income")
                .observe(this, categories -> {
                    CategoryAdapter adapter = new CategoryAdapter(categories, category -> {
                        int resId = getResources().getIdentifier(category.icon, "drawable", getPackageName());
                        ivCategoryIconTransaction.setImageResource(resId);
                        tvCategory.setText(category.name);
                        selectedCategoryId = category.category_id;
                        dialog.dismiss();

                        // ✅ Open Subtype Picker automatically only once for new transactions
                        // ✅ After category selection → open Subtype Picker automatically only once
                        if (transactionId == -1 && !isSubtypeSheetOpenedOnce) {
                            isSubtypeSheetOpenedOnce = true;
                            tvCategory.postDelayed(() -> setupSubtypePicker(), 150);
                        }
                    });
                    rvCategories.setAdapter(adapter);
                });

        // ✅ Use generic util for adding category
        btnAddNewCategory.setOnClickListener(v -> {
            CategoryUtil.openAddCategory(this, isExpense, addCategoryLauncher);
            dialog.dismiss();
        });

        dialog.show();
    }

    private void saveTransaction() {
        String amountStr = etAmount.getText().toString().trim();
        String payeeStr = etPayee.getText().toString().trim();

        // ✅ Validate amount
        if (amountStr.isEmpty()) {
            Toast.makeText(this, "Enter amount", Toast.LENGTH_SHORT).show();
            return;
        }

        // ✅ Validate payee
//        if (payeeStr.isEmpty()) {
//            Toast.makeText(this, "Enter name", Toast.LENGTH_SHORT).show();
//            return;
//        }

        // ✅ Validate category
        if (selectedCategoryId == -1) {
            Toast.makeText(this, "Please select a category", Toast.LENGTH_SHORT).show();
            return;
        }

        // ✅ Validate subtype
        if (selectedSubtypeId == -1) {
            Toast.makeText(this, "Please select a subtype", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount = Double.parseDouble(amountStr);

        Transaction txn = new Transaction();
        txn.user_id = 1;
        txn.amount = amount;
        txn.source_name = payeeStr;
        txn.notes = etNotes.getText().toString().trim();
        txn.date = calendar.getTime();
        txn.type = isExpense ? "Expense" : "Income";
        txn.category_id = selectedCategoryId;
        txn.subtype_id = selectedSubtypeId;
        txn.created_at = new Date();
        txn.updated_at = new Date();

        Executors.newSingleThreadExecutor().execute(() -> {
            db.transactionDao().insert(txn);

            // ✅ Update account balance
//            if (txn.subtype_id != null) {
//                Subtype subtype = db.subtypeDao().getSubtypeById(txn.subtype_id);
//                if (subtype != null) {
//                    long accountId = subtype.account_id;
//                    db.accountDao().updateBalance(accountId,
//                            isExpense ? -amount : amount);
//                }
//            }
            runOnUiThread(this::finish);
        });
    }


    private void updateTransaction() {
        String amountStr = etAmount.getText().toString().trim();
        String payeeStr = etPayee.getText().toString().trim();

        // ✅ Validate amount
        if (amountStr.isEmpty()) {
            Toast.makeText(this, "Enter amount", Toast.LENGTH_SHORT).show();
            return;
        }

        // ✅ Validate payee
//        if (payeeStr.isEmpty()) {
//            Toast.makeText(this, "Enter payee/source name", Toast.LENGTH_SHORT).show();
//            return;
//        }

        // ✅ Validate category
        if (selectedCategoryId == -1) {
            Toast.makeText(this, "Please select a category", Toast.LENGTH_SHORT).show();
            return;
        }

        // ✅ Validate subtype
        if (selectedSubtypeId == -1) {
            Toast.makeText(this, "Please select a subtype", Toast.LENGTH_SHORT).show();
            return;
        }

        double newAmount = Double.parseDouble(amountStr);

        Executors.newSingleThreadExecutor().execute(() -> {
            Transaction txn = db.transactionDao().getTransactionByIdSync(transactionId);
            if (txn != null) {
                double oldAmount = txn.amount;
                boolean wasExpense = "Expense".equalsIgnoreCase(txn.type);

                txn.amount = newAmount;
                txn.source_name = etPayee.getText().toString().trim();
                txn.notes = etNotes.getText().toString().trim();
                txn.date = calendar.getTime();
                txn.type = isExpense ? "Expense" : "Income";
                txn.category_id = (selectedCategoryId != -1) ? selectedCategoryId : null;
                txn.subtype_id = (selectedSubtypeId != -1) ? selectedSubtypeId : null;
                txn.updated_at = new Date();
                db.transactionDao().update(txn);

                // ✅ Recalculate account balance
//                if (txn.subtype_id != null) {
//                    Subtype subtype = db.subtypeDao().getSubtypeById(txn.subtype_id);
//                    if (subtype != null) {
//                        long accountId = subtype.account_id;
//
//                        // Rollback old transaction effect
//                        db.accountDao().updateBalance(accountId,
//                                wasExpense ? oldAmount : -oldAmount);
//
//                        // Apply new transaction effect
//                        db.accountDao().updateBalance(accountId,
//                                isExpense ? -newAmount : newAmount);
//                    }
//                }
            }
            runOnUiThread(this::finish);
        });
    }


    private void deleteTransaction() {
        Executors.newSingleThreadExecutor().execute(() -> {
            Transaction txn = db.transactionDao().getTransactionByIdSync(transactionId);
            if (txn != null) {
                db.transactionDao().delete(txn);

                // ✅ Rollback transaction effect from account
//                if (txn.subtype_id != null) {
//                    Subtype subtype = db.subtypeDao().getSubtypeById(txn.subtype_id);
//                    if (subtype != null) {
//                        long accountId = subtype.account_id;
//                        db.accountDao().updateBalance(accountId,
//                                txn.type.equals("Expense") ? txn.amount : -txn.amount);
//                    }
//                }
            }
            runOnUiThread(this::finish);
        });
    }


    private void loadTransaction(long id) {
        Executors.newSingleThreadExecutor().execute(() -> {
            Transaction txn = db.transactionDao().getTransactionByIdSync(id);
            if (txn != null) {
                runOnUiThread(() -> {
                    // Fill form
                    etAmount.setText(String.valueOf(txn.amount));
                    etPayee.setText(txn.source_name);
                    etNotes.setText(txn.notes);
                    tvDateTime.setText(sdf.format(txn.date));
                    calendar.setTime(txn.date);

                    isExpense = "Expense".equalsIgnoreCase(txn.type);
                    setFilterSelected(isExpense ? tvSpend : tvIncome, isExpense ? tvIncome : tvSpend);
                    updatePayeeLabel();

                    // Category
                    if (txn.category_id != null) {
                        selectedCategoryId = txn.category_id;
                        Executors.newSingleThreadExecutor().execute(() -> {
                            Category category = db.categoryDao().getCategoryById(selectedCategoryId);
                            if (category != null) {
                                runOnUiThread(() -> {
                                    ivCategoryIconTransaction.setImageResource(
                                            getResources().getIdentifier(category.icon, "drawable", getPackageName())
                                    );
                                    tvCategory.setText(category.name);
                                });
                            }
                        });
                    }

                    // Subtype
                    if (txn.subtype_id != null) {
                        selectedSubtypeId = txn.subtype_id;
                        Executors.newSingleThreadExecutor().execute(() -> {
                            Subtype subtype = db.subtypeDao().getSubtypeById(selectedSubtypeId);
                            if (subtype != null) {
                                runOnUiThread(() -> {
                                    ivSubtypeIcon.setImageResource(
                                            getResources().getIdentifier(subtype.icon, "drawable", getPackageName())
                                    );
                                    tvSubtype.setText(subtype.name);
                                });
                            }
                        });
                    }

//                    btnDelete.setVisibility(View.VISIBLE);
                });
            }
        });
    }

    private void updatePayeeLabel() {
        if (isExpense) {
            tvPayeeLabel.setText("Paid to");
            tvAmountTitle.setText("Amount spent");
        } else {
            tvPayeeLabel.setText("Received from");
            tvAmountTitle.setText("Amount received");
        }
    }

    private void clearForm() {
        // Clear text fields
//        etPayee.setText("");
//        etAmount.setText("");
//        etNotes.setText("");

        // Reset category
        tvCategory.setText("Category");
        ivCategoryIconTransaction.setImageResource(R.drawable.ic_category);
        selectedCategoryId = -1;

        // Reset subtype
        tvSubtype.setText("Payment Method");
        ivSubtypeIcon.setImageResource(R.drawable.ic_bank); // <-- make sure you have a default icon
        selectedSubtypeId = -1;

        // Reset datetime to now
        calendar.setTime(new Date());
        //tvDateTime.setText(sdf.format(calendar.getTime()));

        // Reset Spend/Income to default (Expense)
        isExpense = true;
        setFilterSelected(tvSpend, tvIncome);
        updatePayeeLabel();
    }


}
