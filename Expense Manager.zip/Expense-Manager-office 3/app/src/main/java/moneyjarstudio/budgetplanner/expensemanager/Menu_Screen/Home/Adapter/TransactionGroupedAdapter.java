package moneyjarstudio.budgetplanner.expensemanager.Menu_Screen.Home.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import moneyjarstudio.budgetplanner.expensemanager.DB.AppDatabase;
import moneyjarstudio.budgetplanner.expensemanager.DB.entities.Category;
import moneyjarstudio.budgetplanner.expensemanager.DB.entities.Subtype;
import moneyjarstudio.budgetplanner.expensemanager.DB.entities.Transaction;
import moneyjarstudio.budgetplanner.expensemanager.Menu_Screen.Add_Transaction.AddTransactionActivity;
import moneyjarstudio.budgetplanner.expensemanager.R;
import moneyjarstudio.budgetplanner.expensemanager.Util.CurrencyFormatterUtil;
import moneyjarstudio.budgetplanner.expensemanager.Util.SwipeRevealHelper;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;

public class TransactionGroupedAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_TRANSACTION = 1;

    private final Context context;
    private final List<Object> items;
    private final AppDatabase db;
    private final SimpleDateFormat sdf =
            new SimpleDateFormat("hh:mm a", Locale.getDefault());

    public TransactionGroupedAdapter(Context context, List<Object> items, AppDatabase db) {
        this.context = context;
        this.items = items;
        this.db = db;
    }

    @Override
    public int getItemViewType(int position) {
        return (items.get(position) instanceof DateHeader) ? TYPE_HEADER : TYPE_TRANSACTION;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_HEADER) {
            View view = LayoutInflater.from(context)
                    .inflate(R.layout.mockup_item_transaction_grouped_date, parent, false);
            return new HeaderViewHolder(view);
        } else {
            View view = LayoutInflater.from(context)
                    .inflate(R.layout.mockup_item_transaction_entry, parent, false);
            return new TransactionViewHolder(view);
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Object item = items.get(position);

        if (holder instanceof HeaderViewHolder) {
            DateHeader header = (DateHeader) item;
            HeaderViewHolder h = (HeaderViewHolder) holder;

            // Format date parts
            SimpleDateFormat dayFormat = new SimpleDateFormat("dd", Locale.getDefault());
            SimpleDateFormat weekdayFormat = new SimpleDateFormat("EEE", Locale.getDefault());
            SimpleDateFormat monthYearFormat = new SimpleDateFormat("MM.yyyy", Locale.getDefault());

            h.tvDay.setText(dayFormat.format(header.date));
            h.tvWeekday.setText(weekdayFormat.format(header.date));
            h.tvMonthYear.setText(monthYearFormat.format(header.date));

            h.tvIncomeTotal.setText(CurrencyFormatterUtil.format(header.incomeTotal));
            h.tvExpenseTotal.setText(CurrencyFormatterUtil.format(header.expenseTotal));
            h.tvIncomeTotal.setTextColor(Color.parseColor("#388E3C")); // darker green
            h.tvExpenseTotal.setTextColor(Color.parseColor("#DA6C6C")); // darker red


        } else if (holder instanceof TransactionViewHolder) {
            Transaction transaction = (Transaction) item;
            TransactionViewHolder t = (TransactionViewHolder) holder;

            t.tvAmount.setText(CurrencyFormatterUtil.format(transaction.amount));

            t.tvDate.setText(sdf.format(transaction.date));

            // Inside TransactionGroupedAdapter
            t.contentLayout.setOnClickListener(v -> {
                if (item instanceof Transaction) {
                    Transaction txn = (Transaction) item;
                    Intent intent = new Intent(context, AddTransactionActivity.class);
                    intent.putExtra("transaction_id", txn.transaction_id);
                    context.startActivity(intent);
                }
            });


            if (transaction.source_name != null && !transaction.source_name.trim().isEmpty()) {
                t.tvSourceName.setVisibility(View.VISIBLE);
                t.tvSourceName.setText(transaction.source_name);

            } else {
                t.tvSourceName.setVisibility(View.GONE);

            }


            // Notes
            if (transaction.notes != null && !transaction.notes.trim().isEmpty()) {
                t.tvNotes.setVisibility(View.VISIBLE);
                t.tvNotes.setText(transaction.notes);

                t.hr.setVisibility(View.VISIBLE);

            } else {
                t.tvNotes.setVisibility(View.GONE);
                t.hr.setVisibility(View.GONE);

            }

            // ✅ Amount Icon (Income/Expense)
            if ("Income".equalsIgnoreCase(transaction.type)) {
                //t.ivAmountIcon.setImageResource(R.drawable.ic_income);
                GradientDrawable bg = new GradientDrawable();
                bg.setShape(GradientDrawable.OVAL);
                bg.setColor(Color.parseColor("#C8E6C9")); // Light green
                t.bgIconAmount.setBackground(bg);
            } else {
                //t.ivAmountIcon.setImageResource(R.drawable.ic_expense);
                GradientDrawable bg = new GradientDrawable();
                bg.setShape(GradientDrawable.OVAL);
                bg.setColor(Color.parseColor("#FFCDD2")); // Light red
                t.bgIconAmount.setBackground(bg);
            }

            SwipeRevealHelper.attach(
                    t.itemView.findViewById(R.id.contentLayout),
                    t.itemView.findViewById(R.id.btnDeleteBackground),
                    () -> {
                        Executors.newSingleThreadExecutor().execute(() -> {
                            Transaction txn = db.transactionDao().getTransactionByIdSync(transaction.transaction_id);
                            if (txn != null) {
                                // 🗑️ Delete the transaction
                                db.transactionDao().delete(txn);

                                // 🔁 Rollback balance change
                                if (txn.subtype_id != null) {
                                    Subtype subtype = db.subtypeDao().getSubtypeById(txn.subtype_id);
                                    if (subtype != null) {
                                        long accountId = subtype.account_id;
                                        db.accountDao().updateBalance(
                                                accountId,
                                                txn.type.equals("Expense") ? txn.amount : -txn.amount
                                        );
                                    }
                                }
                            }

                            // ✅ Update UI safely after deletion
                            ((Activity) context).runOnUiThread(() -> {
                                int pos = holder.getBindingAdapterPosition(); // safer than getAdapterPosition()
                                if (pos != RecyclerView.NO_POSITION && pos < items.size()) {
                                    removeAt(pos);
                                    notifyItemRangeChanged(pos, items.size() - pos);
                                }
                            });
                        });
                    }
            );




            // Category
            if (transaction.category_id != null) {
                Executors.newSingleThreadExecutor().execute(() -> {
                    Category category = db.categoryDao().getCategoryById(transaction.category_id);
                    if (category != null) {
                        int resId = context.getResources().getIdentifier(
                                category.icon, "drawable", context.getPackageName());

                        ((Activity) context).runOnUiThread(() -> {
                            t.tvCategoryName.setText(category.name);
                            t.ivCategoryIcon.setImageResource(resId);

                            int baseColor = Color.parseColor(category.colorHex);

                            // ✅ Background pastel
                            GradientDrawable bg = new GradientDrawable();
                            bg.setShape(GradientDrawable.OVAL);
                            bg.setColor(baseColor);
                            t.bgIconCategory.setBackground(bg);

                            // ✅ Darker icon
                            int darkerColor = manipulateColor(baseColor, 0.5f);
                            t.ivCategoryIcon.setColorFilter(darkerColor);
                        });
                    }
                });
            }

            // Subtype
            if (transaction.subtype_id != null) {
                Executors.newSingleThreadExecutor().execute(() -> {
                    Subtype subtype = db.subtypeDao().getSubtypeById(transaction.subtype_id);
                    if (subtype != null) {
                        int resId = context.getResources().getIdentifier(
                                subtype.icon, "drawable", context.getPackageName());

                        ((Activity) context).runOnUiThread(() -> {
                            t.tvSubtypeName.setText(subtype.name);
                            t.ivSubtypeIcon.setImageResource(resId);

                            int baseColor = Color.parseColor(subtype.backgroundColorHex);

                            // ✅ Background pastel
                            GradientDrawable bg = new GradientDrawable();
                            bg.setShape(GradientDrawable.OVAL);
                            bg.setColor(baseColor);
                            t.bgIconSubType.setBackground(bg);

                            // ✅ Darker icon
                            int darkerColor = manipulateColor(baseColor, 0.6f);
                            t.ivSubtypeIcon.setColorFilter(darkerColor);
                        });
                    }
                });
            }
        }
    }


    @Override
    public int getItemCount() {
        return items.size();
    }

    // HEADER HOLDER
    static class HeaderViewHolder extends RecyclerView.ViewHolder {
        TextView tvDay, tvWeekday, tvMonthYear, tvIncomeTotal, tvExpenseTotal;

        public HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDay = itemView.findViewById(R.id.tvDay);
            tvWeekday = itemView.findViewById(R.id.tvWeekday);
            tvMonthYear = itemView.findViewById(R.id.tvMonthYear);
            tvIncomeTotal = itemView.findViewById(R.id.tvIncomeTotal);
            tvExpenseTotal = itemView.findViewById(R.id.tvExpenseTotal);
        }
    }

    // TRANSACTION HOLDER
    static class TransactionViewHolder extends RecyclerView.ViewHolder {
        TextView tvCategoryName, tvSubtypeName, tvSourceName, tvNotes, tvAmount, tvDate;
        ImageView ivCategoryIcon, ivSubtypeIcon, ivAmountIcon;
        FrameLayout bgIconCategory, bgIconSubType, bgIconAmount;
        View hr;
        LinearLayout contentLayout;

        public TransactionViewHolder(@NonNull View itemView) {
            super(itemView);
            contentLayout = itemView.findViewById(R.id.contentLayout);
            ivCategoryIcon = itemView.findViewById(R.id.ivCategoryIcon);
            ivSubtypeIcon = itemView.findViewById(R.id.ivSubtypeIcon);
            hr = itemView.findViewById(R.id.hr);
            //ivAmountIcon = itemView.findViewById(R.id.ivAmountIcon);
            bgIconCategory = itemView.findViewById(R.id.bgIconCategory);
            bgIconSubType = itemView.findViewById(R.id.bgIconSubType);
            bgIconAmount = itemView.findViewById(R.id.bgIconAmount);
            tvCategoryName = itemView.findViewById(R.id.tvCategoryName);
            tvSubtypeName = itemView.findViewById(R.id.tvSubtypeName);
            tvSourceName = itemView.findViewById(R.id.tvSourceName);
            tvNotes = itemView.findViewById(R.id.tvNotes);
            tvAmount = itemView.findViewById(R.id.tvAmount);
            tvDate = itemView.findViewById(R.id.tvDate);
        }
    }


    public void updateData(List<Object> newItems) {
        this.items.clear();
        this.items.addAll(newItems);
        notifyDataSetChanged(); // 🔥 can replace with DiffUtil for smooth animations
    }

    private int manipulateColor(int color, float factor) {
        int a = Color.alpha(color);
        int r = Math.round(Color.red(color) * factor);
        int g = Math.round(Color.green(color) * factor);
        int b = Math.round(Color.blue(color) * factor);
        return Color.argb(a,
                Math.min(r, 255),
                Math.min(g, 255),
                Math.min(b, 255));
    }

    public Object getItem(int position) {
        return items.get(position);
    }

    public void removeAt(int position) {
        items.remove(position);
        notifyItemRemoved(position);
    }


}
